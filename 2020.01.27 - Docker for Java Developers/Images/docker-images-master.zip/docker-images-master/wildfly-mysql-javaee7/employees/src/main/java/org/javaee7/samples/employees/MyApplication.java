package org.javaee7.samples.employees;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * @author arungupta
 */
@ApplicationPath("resources")
public class MyApplication extends Application {
    
}
