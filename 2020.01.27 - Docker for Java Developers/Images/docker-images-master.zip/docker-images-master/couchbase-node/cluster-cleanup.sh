docker-machine stop consul-machine swarm-master swarm-node-01 swarm-node-02
docker-machine rm consul-machine swarm-master swarm-node-01 swarm-node-02
